import mongoose from "mongoose";

export const connectDB=async () =>{
    await mongoose.connect('mongodb+srv://tomato:10092003@cluster0.jwnqy.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0').then(()=>console.log("DB Connected"));
}