import mongoose from "mongoose";

const userSchema=new mongoose.Schema({
    name:{type:String,required:true},
    email:{type:String,required:true,unique:true}, //unique:true so that the email id that once registered on the database can not be register again.
    password:{type:String,required:true},
    cartData:{type:Object,default:{}}
},{minimize:false}) // if we don't provide false here then the data will not be created because we are not providing any data here that's why we have created minimize so the cart data entry be created without any data.

const userModel=mongoose.models.user || mongoose.model("user",userSchema);//if the model is created then it will be used otherwise it will craete a new model

export default userModel;